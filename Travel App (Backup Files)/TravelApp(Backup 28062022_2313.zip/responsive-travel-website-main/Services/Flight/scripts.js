
const searchflights = !!document.getElementById('FlightSearch');

async function MyFlightSearch() {
  addEventListener('submit', async function (event) {
    event.preventDefault();

    var source = document.getElementById('inputGroupSelect01').value;
    console.log("from_station:", source);
  
    var destination = document.getElementById('inputGroupSelect02').value;
    console.log("Destination:", destination);
  
    var travel_date = document.getElementById('input-groupDate').value;
    console.log("from_station:", travel_date);
  
    let url_string = "https://flightserviceapitest.herokuapp.com/search";

    url_string = url_string + "?source="+source+"&destination="+destination+"&travel_date="+travel_date;

    console.log("API LINK");

    console.log(url_string);



    // var xhr = new XMLHttpRequest()
    // xhr.open("GET", url_string);
    // xhr.responseType = 'json';
    // xhr.withCredentials = true;
    // xhr.onload = function (e) {
    //   if (this.status == 200) {
    //     console.log('response', this.response); // JSON response  
    //   }
    // };
    // xhr.send();
    // console.log(xhr);



    // const response = await fetch(url_string);

    // const enquiredata = await response.json();
    // console.log(enquiredata);
  
    // const data = await response.json();
    // console.log(data);

  //   const domElementsToBeUpdated = [...document.getElementsByTagName('span')].filter(i => i.id);

  //   domElementsToBeUpdated.forEach(function (elem) {
  //     document.getElementById(elem.id).innerHTML = elem.id === "path" && !!enquiredata.via ? enquiredata.via[elem.idx] : enquiredata[elem.id]
  // })
  

  })
}


if(searchflights)
{
  MyFlightSearch();
}