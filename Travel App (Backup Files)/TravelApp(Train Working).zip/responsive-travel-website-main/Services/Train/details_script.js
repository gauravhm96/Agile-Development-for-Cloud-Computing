const responseData = JSON.parse(localStorage.getItem('responseData'));

const domElementsToBeUpdated = [...document.getElementsByTagName('span')].filter(i => i.id);

domElementsToBeUpdated.forEach(function (elem) {
    document.getElementById(elem.id).innerHTML = responseData[elem.id]
})
