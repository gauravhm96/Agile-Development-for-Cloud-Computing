let TrainBookings = [];
// example {uuid : Unique User ID
//          from_station : From station
//          to_station: To station
//          date_time: 20220615090105; Format: YYYYMMDDhhmmss
//          class: Class as 1st or 2nd; valid input: 1 or 2
//          no_of_passenger: Number of passengers
//          special_service_flag: Special Service Flag
//          seats: Number of seats to reserve
//          food_service: Food Service required
//          luggage_service: Luggage Service required}

const addBooking = (ev)=>{
    ev.preventDefault();  //to stop the form submitting
    let TrainBooking = {
        uuid: document.getElementById('inputUUID').value ,
        from_station: document.getElementById('inputGroupSelect01').value,
        to_station:document.getElementById('inputGroupSelect02').value,
        date_time:document.getElementById('inputdates').value,
        class:document.getElementById('inputClass').value,
        no_of_passenger:document.getElementById('inputNumberofPassengersSpcSrv').getElementById(input-group).value,
        special_service_flag:document.getElementById('inputNumberofPassengersSpcSrv').getElementById(input-group1).value,
        seats:document.getElementById('inputNumberofPassengersSpcSrv').getElementById(input-group).value,
        food_service:document.getElementById('inputFoodLuggage').getElementById(input-group).value,
        luggage_service:document.getElementById('inputFoodLuggage').getElementById(input-group1).value,
    }
    TrainBookings.push(TrainBooking);
    document.forms[0].reset(); // to clear the form for the next entries
    //document.querySelector('form').reset();

    //for display purposes only
    console.warn('added' , {TrainBookings} );
    let pre = document.querySelector('#msg pre');
    pre.textContent = '\n' + JSON.stringify(TrainBookings, '\t', 2);

    //saving to localStorage
    localStorage.setItem('MyMovieList', JSON.stringify(TrainBookings) );
}
document.addEventListener('DOMContentLoaded', ()=>{
    document.getElementById('btn').addEventListener('click', addBooking);
});